# NFLBigDataBowl
A refined scouting report (UI) that integrates NFL tracking, play, and game data to train XGBoost models predicting outcomes like yards gained and touchdown probability.
